-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: chordian.net.mysql.service.one.com:3306
-- Generation Time: May 18, 2024 at 06:39 AM
-- Server version: 10.6.15-MariaDB-1:10.6.15+maria~ubu2204
-- PHP Version: 8.1.2-1ubuntu2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chordian_net_deepsid`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `folder` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `redirect` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `folder`, `name`, `redirect`) VALUES
(1, 'Richard Rinn (Deek)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/D/Deek'),
(2, 'Thomas Mogensen (DRAX)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/D/DRAX'),
(3, 'Jens-Christian Huus (JCH)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/J/JCH'),
(4, 'Jesper Olsen (JO)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/J/JO'),
(5, 'Thomas Egeskov Petersen (Laxity)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/L/Laxity'),
(6, 'Klaus Grøngaard (Link)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/L/Link'),
(7, 'Torben Hansen (Metal)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/M/Metal'),
(8, 'Morten Sigaard Kristensen (MSK)', 'Vibrants', '_High Voltage SID Collection/MUSICIANS/M/MSK'),
(10, 'Thomas Mogensen (DRAX)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/D/DRAX'),
(11, 'Thomas Egeskov Petersen (Laxity)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/L/Laxity'),
(12, 'Jeroen Tel (WAVE)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/T/Tel_Jeroen'),
(13, 'Charles Deenen', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/D/Deenen_Charles'),
(14, 'Markus Klein (LMan)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/L/LMan'),
(15, 'Geir Tjelta', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/T/Tjelta_Geir'),
(16, 'Paul Hesford (Sidman)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/H/Hesford_Paul'),
(17, 'Søren Lund (Jeff)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/J/Jeff'),
(18, 'Johannes Bjerregaard', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/B/Bjerregaard_Johannes'),
(19, 'Marcel Donné (Mad)', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/M/Mad_Donne_Marcel'),
(20, 'Reyn Ouwehand', 'Maniacs of Noise', '_High Voltage SID Collection/MUSICIANS/O/Ouwehand_Reyn'),
(21, 'Roy Johan Widding (Crockett)', 'Jolly Poppers', '_High Voltage SID Collection/MUSICIANS/W/Widding_Roy_Johan'),
(22, 'Vidar Bang (Drumtex)', 'Jolly Poppers', '_High Voltage SID Collection/MUSICIANS/D/Drumtex'),
(23, 'Magnar Harestad (Lizard)', 'Jolly Poppers', '_High Voltage SID Collection/MUSICIANS/M/Magnar'),
(24, 'Anders Rodahl (Rage)', 'Jolly Poppers', '_High Voltage SID Collection/MUSICIANS/R/Rage'),
(25, 'Ruben Spaans (Scroll)', 'Jolly Poppers', '_High Voltage SID Collection/MUSICIANS/S/Scroll'),
(26, 'Geir Tjelta (Predator)', 'Moz(IC)art', '_High Voltage SID Collection/MUSICIANS/T/Tjelta_Geir'),
(27, 'Trond Kjetil Lindanger (IQ64)', 'Moz(IC)art', '_High Voltage SID Collection/MUSICIANS/L/Lindanger_Trond'),
(28, 'Gerard Hultink (GH)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/H/Hultink_Gerard'),
(29, 'Michal Hoffmann', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/H/Hoffmann_Michal'),
(30, 'Kamil Wolnikowski (Jammer)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/J/Jammer'),
(31, 'Jason Page', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/P/Page_Jason'),
(32, 'Markus Klein (LMan)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/L/LMan'),
(33, 'Sascha Zeidler (Linus)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/L/Linus'),
(34, 'Michal Brzeski (MCH)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/M/MCH'),
(35, 'Michael Bridgewater (Mibri)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/M/Mibri'),
(36, 'Wojciech Radziejewski (Shogoon)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/S/Shogoon'),
(37, 'Uwe Anfang (THCM)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/T/THCM'),
(38, 'Alexander Wiklund (Wiklund)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/W/Wiklund'),
(39, 'Marcin Kubica (Booker)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/B/Booker'),
(40, 'Marcin Majdzik (psych858o)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/P/Psych858o'),
(41, 'Marcin Romanowski (Sidder)', 'MultiStyle Labs', '_High Voltage SID Collection/MUSICIANS/S/Sidder'),
(42, 'Edwin van Santen', '20th Century Composers', '_High Voltage SID Collection/MUSICIANS/0-9/20CC/van_Santen_Edwin'),
(43, 'Falco Paul', '20th Century Composers', '_High Voltage SID Collection/MUSICIANS/0-9/20CC/Paul_Falco'),
(44, 'Lars Hoff', 'Prosonix', '_High Voltage SID Collection/MUSICIANS/P/Prosonix/Hoff_Lars'),
(45, 'Ole Marius Pettersen', 'Prosonix', '_High Voltage SID Collection/MUSICIANS/P/Prosonix/Pettersen_Ole_Marius'),
(46, 'Stein Pedersen (Stone)', 'Prosonix', '_High Voltage SID Collection/MUSICIANS/P/Prosonix/Pedersen_Stein'),
(47, 'Diderich Buch (Lynx)', 'Prosonix', '_High Voltage SID Collection/MUSICIANS/P/Prosonix/Lynx'),
(48, 'Rodney Balai', 'Audial Arts', '_High Voltage SID Collection/MUSICIANS/A/Audial_Arts/Balai_Rodney'),
(49, 'Ronny Pasch', 'Audial Arts', '_High Voltage SID Collection/MUSICIANS/A/Audial_Arts/Pasch_Ronny'),
(50, 'Patrick Peters (Softmaster)', 'Audial Arts', '_High Voltage SID Collection/MUSICIANS/A/Audial_Arts/Peters_Patrick'),
(51, 'Francois Prijt', 'Audial Arts', '_High Voltage SID Collection/MUSICIANS/A/Audial_Arts/Prijt_Francois'),
(52, 'Arjen Bokhoven (Harlequin)', 'Audial Arts', '_High Voltage SID Collection/MUSICIANS/H/Harlequin'),
(53, 'Tim Straten', 'Audial Arts', '_High Voltage SID Collection/MUSICIANS/A/Audial_Arts'),
(54, 'Peter Slotta (Fate)', 'Beat Machine', '_High Voltage SID Collection/MUSICIANS/F/Fate'),
(55, 'Chris Ammermüller (Chris)', 'Beat Machine', '_High Voltage SID Collection/MUSICIANS/B/Beat_Machine/Chris'),
(56, 'Giuseppe Musardo (Xayne)', 'Beat Machine', '_High Voltage SID Collection/MUSICIANS/B/Beat_Machine/Xayne'),
(57, 'Glenn Gallefoss (6R6)', 'Blues Muz\'', '_High Voltage SID Collection/MUSICIANS/B/Blues_Muz/Gallefoss_Glenn'),
(58, 'Kjell Nordbø', 'Blues Muz\'', '_High Voltage SID Collection/MUSICIANS/B/Blues_Muz/Nordboe_Kjell'),
(59, 'Kristian Røstøen', 'Blues Muz\'', '_High Voltage SID Collection/MUSICIANS/B/Blues_Muz/Roestoeen_Kristian'),
(60, 'Eivind Sommersten', 'Blues Muz\'', '_High Voltage SID Collection/MUSICIANS/B/Blues_Muz/Sommersten_Eivind'),
(61, 'Dwayne Bakewell (DJB)', 'Blues Muz\'', '_High Voltage SID Collection/MUSICIANS/B/Bakewell_Dwayne'),
(62, 'Huseyin Kilic (Wisdom)', 'Blues Muz\'', '_High Voltage SID Collection/MUSICIANS/W/Wisdom'),
(63, 'Frank Schäfers', 'The Rockin\' Limited', '_High Voltage SID Collection/MUSICIANS/R/Rockin_Limited/Schaefers_Frank'),
(64, 'Jörg Schäfers (Doc)', 'The Rockin\' Limited', '_High Voltage SID Collection/MUSICIANS/R/Rockin_Limited/Schaefers_Joerg'),
(65, 'Graham Jarvis', 'Clever Music', '_High Voltage SID Collection/MUSICIANS/C/Clever_Music'),
(66, 'Robert Hartshorne', 'Clever Music', '_High Voltage SID Collection/MUSICIANS/C/Clever_Music'),
(67, 'Michael Hendriks (Mike)', 'F.A.M.E.', '_High Voltage SID Collection/MUSICIANS/F/FAME/Hendriks_Michael'),
(68, 'Holger Knipping (Holly)', 'F.A.M.E.', '_High Voltage SID Collection/MUSICIANS/F/FAME/Knipping_Holger'),
(69, 'Adam Bulka (Adam)', 'F.A.M.E.', '_High Voltage SID Collection/MUSICIANS/F/FAME'),
(70, 'Marvin Severijns (Yavin)', 'HeatWave', '_High Voltage SID Collection/MUSICIANS/H/HeatWave/Yavin'),
(71, 'Michel de Bree (youtH)', 'HeatWave', '_High Voltage SID Collection/MUSICIANS/H/HeatWave/youtH'),
(72, 'Dennis Middelkoop (Hires)', 'HeatWave', '_High Voltage SID Collection/MUSICIANS/H/HeatWave'),
(73, 'Kaspar Dahlquist (Evony)', 'Nordic Beat', '_High Voltage SID Collection/MUSICIANS/N/Nordic_Beat/Evony'),
(74, 'Daniel Hansson (Matrix)', 'Nordic Beat', '_High Voltage SID Collection/MUSICIANS/N/Nordic_Beat/Matrix'),
(75, 'Jakob Mellander (Quan)', 'Nordic Beat', '_High Voltage SID Collection/MUSICIANS/N/Nordic_Beat/Quan'),
(76, 'Jeroen Soede', 'SoedeSoft', '_High Voltage SID Collection/MUSICIANS/S/SoedeSoft/Soede_Jeroen'),
(77, 'Michiel Soede', 'SoedeSoft', '_High Voltage SID Collection/MUSICIANS/S/SoedeSoft/Soede_Michiel'),
(78, 'David Hayes (Ben)', 'Sonic Graffiti', '_High Voltage SID Collection/MUSICIANS/S/Sonic_Graffiti/Hayes_Ben'),
(79, 'Gerard Gourley', 'Sonic Graffiti', '_High Voltage SID Collection/MUSICIANS/S/Sonic_Graffiti/Gourley_Gerard'),
(80, 'Richard Rinn (Deek)', 'Sonic Graffiti', '_High Voltage SID Collection/MUSICIANS/D/Deek'),
(81, 'Chris Lightfoot (Chris)', 'Sonic Graffiti', '_High Voltage SID Collection/MUSICIANS/T/TLF'),
(82, 'Rafal Kazimierski (Asterion)', 'Tinnitus', '_High Voltage SID Collection/MUSICIANS/T/Tinnitus/Asterion'),
(83, 'Maciej Stankiewicz (Trompkins)', 'Tinnitus', '_High Voltage SID Collection/MUSICIANS/T/Tinnitus/Trompkins'),
(84, 'Mariusz Cichy (Borgon)', 'Tinnitus', '_High Voltage SID Collection/MUSICIANS/T/Tinnitus'),
(85, 'Balazs Farkas (Brian)', 'The Imperium Arts', '_High Voltage SID Collection/MUSICIANS/B/Brian'),
(86, 'Sanke Michael Choe (SMC)', 'The Imperium Arts', '_High Voltage SID Collection/MUSICIANS/S/SMC'),
(87, 'Matthias Hartung (The Syndrom)', 'The Imperium Arts', '_High Voltage SID Collection/MUSICIANS/T/The_Syndrom'),
(88, 'Sebastian Thiel (Gaston)', 'The Imperium Arts', '_High Voltage SID Collection/MUSICIANS/G/Gaston'),
(89, 'Volker Meitz (PRI)', 'The Imperium Arts', '_High Voltage SID Collection/MUSICIANS/P/PRI'),
(90, 'Ringo Reuter (Tragic Error)', 'The Imperium Arts', '_High Voltage SID Collection/MUSICIANS/T/Tragic_Error'),
(91, 'Markus Schneider', 'Lords of Sonics', '_High Voltage SID Collection/MUSICIANS/S/Schneider_Markus'),
(92, 'Jens Blidon', 'Lords of Sonics', '_High Voltage SID Collection/MUSICIANS/B/Blidon_Jens'),
(93, 'Danny Bouzaglo (Danny)', 'Sidchip Scratchers', '_High Voltage SID Collection/MUSICIANS/D/DB'),
(94, 'Guy Shavitt', 'Sidchip Scratchers', '_High Voltage SID Collection/MUSICIANS/S/Shavitt_Guy'),
(95, 'Chris Hülsbeck', 'A.U.D.I.O.S. Entertainment', '_High Voltage SID Collection/MUSICIANS/H/Huelsbeck_Chris'),
(96, 'Ramiro Vaca', 'A.U.D.I.O.S. Entertainment', '_High Voltage SID Collection/MUSICIANS/V/Vaca_Ramiro'),
(97, 'Peter Thierolf', 'A.U.D.I.O.S. Entertainment', '_High Voltage SID Collection/MUSICIANS/T/Thierolf_Peter'),
(98, 'Roman Majewski (Compod)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/C/Compod'),
(99, 'Boleslaw Ogrodowczyk (Froyd)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/F/Froyd'),
(100, 'Marcin Olkowski (Olsen)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/O/Olsen'),
(101, 'Dariusz Rawa (Spike)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/S/Spike'),
(102, 'Marcin Kubica (Booker)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/B/Booker'),
(103, 'Norbert Kowalski (Cleve)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/C/Cleve'),
(104, 'Sebastian Bachlinski (Moog)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/M/Moog'),
(105, 'Adam Waclawski (Wacek)', 'Amorphis', '_High Voltage SID Collection/MUSICIANS/W/Wacek'),
(106, 'Wally Beben (Hagar)', 'Ariston Design', '_High Voltage SID Collection/MUSICIANS/B/Beben_Wally'),
(107, 'Denis Harris (Moley)', 'Ariston Design', '_High Voltage SID Collection/MUSICIANS/H/Harris_Denis'),
(108, 'Neil Scales (Neil)', 'Ariston Design', '_High Voltage SID Collection/MUSICIANS/S/Scales_Neil'),
(109, 'Rene Griebel (Bleed Into One)', 'Bass', '_High Voltage SID Collection/MUSICIANS/B/Bleed_Into_One'),
(110, 'Kay Tichelmann (Echo)', 'Bass', '_High Voltage SID Collection/MUSICIANS/T/Tichelmann_Kay'),
(111, 'Alexander Rotzsch (Fanta)', 'Bass', '_High Voltage SID Collection/MUSICIANS/F/Fanta'),
(112, 'Dwayne Bakewell (Morbid)', 'Bass', '_High Voltage SID Collection/MUSICIANS/B/Bakewell_Dwayne'),
(113, 'Jimmy Nielsen (Shogun)', 'Anzac', '_High Voltage SID Collection/MUSICIANS/S/Shogun'),
(114, 'Søren Bovbjerg (Zeus)', 'Anzac', '_High Voltage SID Collection/MUSICIANS/Z/Zeus_Anzac'),
(115, 'Anders Daugaard (Duck LaRock)', 'Cyberzound Productions', '_High Voltage SID Collection/MUSICIANS/D/Duck_LaRock'),
(116, 'Søren Lund (Jeff)', 'Cyberzound Productions', '_High Voltage SID Collection/MUSICIANS/J/Jeff'),
(117, 'Michael Nilsson-Vonderburgh (Mitch)', 'Cyberzound Productions', '_High Voltage SID Collection/MUSICIANS/M/Mitch_and_Dane/Mitch'),
(118, 'Vincent Merken (Vip)', 'Cyberzound Productions', '_High Voltage SID Collection/MUSICIANS/M/Merken_Vincent'),
(119, 'Sascha Nagie (celticdesign)', 'Demons of Sound', '_High Voltage SID Collection/MUSICIANS/N/Nagie_Sascha'),
(120, 'Oliver Klee (Odi)', 'Demons of Sound', '_High Voltage SID Collection/MUSICIANS/O/Odi'),
(121, 'Lars Hutzelmann (The Blue Ninja)', 'Demons of Sound', '_High Voltage SID Collection/MUSICIANS/T/The_Blue_Ninja'),
(122, 'Glenn Gallefoss (Shark)', 'Kraftverk', '_High Voltage SID Collection/MUSICIANS/B/Blues_Muz/Gallefoss_Glenn'),
(123, 'Egil Pedersen (Zipper)', 'Kraftverk', '_High Voltage SID Collection/MUSICIANS/Z/Zipper'),
(124, 'István Szödényi Jr. (Chubrock)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/C/Chubrock'),
(125, 'Péter Molnár (Peet)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/P/Peet'),
(126, 'Balázs Takács (Taki)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/T/Taki'),
(127, 'László Benke Jr. (Dec)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/D/Dec'),
(128, 'Jens Leiers (Decoy)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/D/Decoy'),
(129, 'Szabolcs Bíró (Mercury)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/M/Mercury'),
(130, 'Szabolcs Beleznai (Silc)', 'Natural Beat', '_High Voltage SID Collection/MUSICIANS/S/Silc'),
(131, 'Ewen Gillies', 'Noise Masters International', '_High Voltage SID Collection/MUSICIANS/G/Gillies_Ewen'),
(132, 'Michael Colin', 'Noise Masters International', '_High Voltage SID Collection/MUSICIANS/C/Colin_Michael'),
(133, 'Anders Carlsson (Goto80)', 'Oxsid Planetary', '_High Voltage SID Collection/MUSICIANS/G/Goto80'),
(134, 'Gábor Mucsányi (QBhead)', 'Oxsid Planetary', '_High Voltage SID Collection/MUSICIANS/C/Cubehead'),
(135, 'Johan Åstrand (Zyron)', 'Oxsid Planetary', '_High Voltage SID Collection/MUSICIANS/Z/Zyron'),
(136, 'Toni Cavén (Ferrara)', 'phObos team', '_High Voltage SID Collection/MUSICIANS/F/Ferrara'),
(137, 'Juha Jaakkola (Warlord)', 'phObos team', '_High Voltage SID Collection/MUSICIANS/W/Warlord'),
(138, 'Jurgen van Dongen (JVD)', 'Rhythmic Lunatics', '_High Voltage SID Collection/MUSICIANS/J/JVD'),
(139, 'Pascal van Loosbroek (PVL)', 'Rhythmic Lunatics', '_High Voltage SID Collection/MUSICIANS/P/PVL'),
(140, 'Ruud den Bekker (Twynn)', 'Rhythmic Lunatics', '_High Voltage SID Collection/MUSICIANS/T/Twynn'),
(141, 'Torben Hansen (Metal)', 'Sacred Noise', '_High Voltage SID Collection/MUSICIANS/M/Metal'),
(142, 'Thomas Bendt (Scortia)', 'Sacred Noise', '_High Voltage SID Collection/MUSICIANS/S/Scortia'),
(143, 'Anders Øland (Zonix)', 'Sacred Noise', '_High Voltage SID Collection/MUSICIANS/Z/Zonix'),
(144, 'Jörg Rosenstiel (Sharon)', 'Sharon Soundworks', '_High Voltage SID Collection/MUSICIANS/R/Rosenstiel_Joerg'),
(145, 'Michael Simon', 'Sharon Soundworks', '_High Voltage SID Collection/MUSICIANS/S/Simon_Michael'),
(146, 'Sven Schlünzen', 'Sharon Soundworks', '_High Voltage SID Collection/MUSICIANS/S/Schluenzen_Sven'),
(147, 'Juha-Matti Hilpinen (AudioMaster J)', 'Side B', '_High Voltage SID Collection/MUSICIANS/A/AMJ'),
(148, 'Jouni Ikonen (Mixer)', 'Side B', '_High Voltage SID Collection/MUSICIANS/M/Mixer'),
(149, 'Tero Hilpinen (The Beasty Boy)', 'Side B', '_High Voltage SID Collection/MUSICIANS/T/TBB'),
(150, 'Toni Hilpinen (Page)', 'Side B', '_High Voltage SID Collection/MUSICIANS/P/Page'),
(151, 'Petri Reiman (Anvil)', 'Side B', '_High Voltage SID Collection/MUSICIANS/A/Anvil'),
(152, 'Ari-Pekka Paljakka (Zardax)', 'Side B', '_High Voltage SID Collection/MUSICIANS/Z/Zardax'),
(153, 'Ben Daglish (Benn)', 'WE M.U.S.I.C.', '_High Voltage SID Collection/MUSICIANS/D/Daglish_Ben'),
(154, 'Antony Crowther (Ratt)', 'WE M.U.S.I.C.', '_High Voltage SID Collection/MUSICIANS/C/Crowther_Antony'),
(155, 'David Hayes (Ben)', 'System 6581', '_High Voltage SID Collection/MUSICIANS/S/Sonic_Graffiti/Hayes_Ben'),
(156, 'Fredrik Segerfalk (Moppe)', 'System 6581', '_High Voltage SID Collection/MUSICIANS/M/Moppe'),
(157, 'Fredrik Hederstierna (Zizyphus)', 'System 6581', '_High Voltage SID Collection/MUSICIANS/Z/Zizyphus'),
(158, 'Thomas Mogensen (DRAX)', 'Unitech Designs', '_High Voltage SID Collection/MUSICIANS/D/DRAX'),
(159, 'Torben Hansen (Metal)', 'Unitech Designs', '_High Voltage SID Collection/MUSICIANS/M/Metal'),
(160, 'Johan Elm (Slash)', 'The Electronic Knights', '_High Voltage SID Collection/MUSICIANS/S/Slash'),
(161, 'Christof Mühlan (Banana)', 'The Electronic Knights', '_High Voltage SID Collection/MUSICIANS/B/Banana'),
(162, 'Alexander Kern (Mac)', 'The Electronic Knights', '_High Voltage SID Collection/MUSICIANS/M/Mac_TEK'),
(163, 'Kim Christensen (Future Freak)', 'The Flexible Arts', '_High Voltage SID Collection/MUSICIANS/F/Future_Freak'),
(164, 'Thomas Egeskov Petersen (Laxity)', 'The Flexible Arts', '_High Voltage SID Collection/MUSICIANS/L/Laxity'),
(165, 'Nicolai Thilo (Zenox)', 'The Flexible Arts', '_High Voltage SID Collection/MUSICIANS/Z/Zenox'),
(166, 'Michael Zuurman (Mr. Mouse)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/M/Mr_Mouse'),
(167, 'Arjan van der Werf (Active)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/A/Active'),
(168, 'Roel Heerspink (Cerror)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/C/Cerror'),
(169, 'Ralf Ewe (Cyberdyne / The Stranger)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/C/Cyberdyne'),
(170, 'Brian Reid (Gop)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/G/Gop'),
(171, 'Ondrej Matejka (Mateus)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/M/Mateus'),
(172, 'Nantco Bakker (Nantco)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/B/Bakker_Nantco'),
(173, 'Thomas Manske (Peace)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/K/Kasmo'),
(174, 'Martin Pilný (Pina)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/P/Pina'),
(175, 'Emile van den Akker (The Gee)', 'Xentax', '_High Voltage SID Collection/MUSICIANS/T/The_Gee'),
(176, 'Vincent Merken (Vip / _V_)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/M/Merken_Vincent'),
(177, 'Mark Ross (MTR1975)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/R/Ross_Mark'),
(178, 'Søren Lund (Jeff)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/J/Jeff'),
(179, 'Niklas Sjösvärd (Zabutom)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/Z/Zabutom'),
(180, 'Owen Crowley (Conrad)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/C/Crowley_Owen'),
(181, 'Alexander Rotzsch (Fanta)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/F/Fanta'),
(182, 'Sascha Zeidler (Linus)', 'Viruz', '_High Voltage SID Collection/MUSICIANS/L/Linus'),
(183, 'Adam Morton (Adam)', 'SIDwave', '_High Voltage SID Collection/MUSICIANS/M/Morton_Adam'),
(184, 'Marcin Kubica (Booker)', 'SIDwave', '_High Voltage SID Collection/MUSICIANS/B/Booker'),
(185, 'Jan Harries (Rambones / SIDWAVE)', 'SIDwave', '_High Voltage SID Collection/MUSICIANS/S/SIDwave'),
(186, 'Martin Nordell (Maktone)', 'SIDwave', '_High Voltage SID Collection/MUSICIANS/M/Maktone'),
(187, 'Andrew Lemon (ne7)', 'SIDwave', '_High Voltage SID Collection/MUSICIANS/N/Ne7'),
(188, 'Péter Nagy-Miklós (NecroPolo)', 'SIDwave', '_High Voltage SID Collection/MUSICIANS/N/NecroPolo'),
(189, 'Jonas Håkansson (Avalon)', 'Swemix', '_High Voltage SID Collection/MUSICIANS/A/Avalon'),
(190, 'Jesper Värn (Decoder)', 'Swemix', '_High Voltage SID Collection/MUSICIANS/D/Decoder'),
(191, 'Stefan Berglind (Doxx)', 'Swemix', '_High Voltage SID Collection/MUSICIANS/D/Doxx'),
(192, 'Emil Helldin (Red Devil)', 'Swemix', '_High Voltage SID Collection/MUSICIANS/R/Red_Devil'),
(193, 'Johan Åstrand (Zyron)', 'Swemix', '_High Voltage SID Collection/MUSICIANS/Z/Zyron'),
(194, 'Bill Pamier (Image)', 'Warriors of Music', '_High Voltage SID Collection/MUSICIANS/I/Image'),
(195, 'Angelo Barbera (Ispace)', 'Warriors of Music', '_High Voltage SID Collection/MUSICIANS/I/Ispace'),
(196, 'Johan Danielsson (JLD)', 'Warriors of Music', '_High Voltage SID Collection/MUSICIANS/J/JLD'),
(197, 'Nantco Bakker (Nantco)', 'Warriors of Music', '_High Voltage SID Collection/MUSICIANS/B/Bakker_Nantco'),
(198, 'Kris Blomme (Skysurfer)', 'Warriors of Music', '_High Voltage SID Collection/MUSICIANS/S/Skysurfer'),
(199, 'Csaba Rácz (Chabee)', 'SIDRIP Alliance', '_High Voltage SID Collection/MUSICIANS/C/Chabee'),
(200, 'Péter Nagy-Miklós (NecroPolo)', 'SIDRIP Alliance', '_High Voltage SID Collection/MUSICIANS/N/NecroPolo'),
(201, 'László Vincze (Vincenzo)', 'SIDRIP Alliance', '_High Voltage SID Collection/MUSICIANS/V/Vincenzo'),
(202, 'Mihály Horváth (Hermit)', 'SIDRIP Alliance', '_High Voltage SID Collection/MUSICIANS/H/Hermit'),
(203, 'Arjen Bokhoven (Harlequin)', 'Sonical Dreams', '_High Voltage SID Collection/MUSICIANS/H/Harlequin'),
(204, 'Markus Funk (MF)', 'Sonical Dreams', '_High Voltage SID Collection/MUSICIANS/W/Wiz-Art'),
(205, 'Peter Slotta (Fate)', 'Sonical Dreams', '_High Voltage SID Collection/MUSICIANS/F/Fate'),
(206, 'Rudolf Stember (Rudi)', 'Sonical Dreams', '_High Voltage SID Collection/MUSICIANS/S/Stember_Rudolf'),
(207, 'Linus Nielsen (Boogaloo)', 'SkyLine Technics', '_High Voltage SID Collection/MUSICIANS/B/Boogaloo'),
(208, 'Sanke Michael Choe (SMC)', 'SkyLine Technics', '_High Voltage SID Collection/MUSICIANS/S/SMC'),
(209, 'Björn Stenberg (Zagor)', 'SkyLine Technics', '_High Voltage SID Collection/MUSICIANS/Z/Zagor'),
(210, 'Sean Connolly (Odie)', 'Sonix Systems', '_High Voltage SID Collection/MUSICIANS/C/Connolly_Sean'),
(211, 'Marc François (Skywave)', 'Sonix Systems', '_High Voltage SID Collection/MUSICIANS/F/Francois_Marc'),
(212, 'Elton de Hoog', 'Toondichters', '_High Voltage SID Collection/MUSICIANS/D/de_Hoog_Elton'),
(213, 'Gerard Hultink (GH)', 'Toondichters', '_High Voltage SID Collection/MUSICIANS/H/Hultink_Gerard'),
(214, 'Marc van den Bovenkamp (No-XS)', 'Toondichters', '_High Voltage SID Collection/MUSICIANS/N/No-XS'),
(215, 'Markus Jentsch (c0zmo)', 'Welle:Erdball', '_High Voltage SID Collection/MUSICIANS/C/C0zmo'),
(216, 'Hannes Malecki (Honey)', 'Welle:Erdball', '_High Voltage SID Collection/MUSICIANS/H/Honey'),
(217, 'Zoltán Földi (Eclipse)', 'Xymox', '_High Voltage SID Collection/MUSICIANS/E/Eclipse'),
(218, 'Konrád Kiss (Con)', 'Xymox', '_High Voltage SID Collection/MUSICIANS/K/Kiss_Konrad'),
(219, 'Attila Szõke (da Blondie)', 'Xymox', '_High Voltage SID Collection/MUSICIANS/D/Da_Blondie'),
(220, 'Timo Taipalus (Abaddon)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/A/Abaddon'),
(221, 'Antti Hannula (Flex)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/H/Hannula_Antti'),
(222, 'Jaakko Viitalähde (Aomeba)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/A/Aomeba'),
(223, 'Tero Rönnqvist (Apollyon)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/A/Apollyon'),
(224, 'Jani Joeli (Frostbyte)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/J/Joeli_Jani'),
(225, 'Jaakko Luoto (jab)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/J/Jab'),
(226, 'Janne Hannula (Jangler)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/H/Hannula_Janne'),
(227, 'Jussi Hannula (Juzdie)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/J/Juzdie'),
(228, 'Sami Juntunen (Mutetus)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/M/Mutetus'),
(229, 'Antti Kangas (Scorpion)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/S/Scorpion'),
(230, 'Petrik Salovaara (Yip)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/Y/Yip'),
(231, 'Ari-Pekka Paljakka (Zardax)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/Z/Zardax'),
(232, 'Riku Ö (Flotsam)', 'Artline Designs', '_High Voltage SID Collection/MUSICIANS/F/Flotsam'),
(233, 'Riku Ö (Flotsam)', 'sidDivers', '_High Voltage SID Collection/MUSICIANS/F/Flotsam'),
(234, 'Benny Härdin (Mythus)', 'sidDivers', '_High Voltage SID Collection/MUSICIANS/M/Mythus');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
