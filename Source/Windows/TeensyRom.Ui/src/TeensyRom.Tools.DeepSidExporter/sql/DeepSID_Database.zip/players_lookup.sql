-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: chordian.net.mysql.service.one.com:3306
-- Generation Time: May 18, 2024 at 06:39 AM
-- Server version: 10.6.15-MariaDB-1:10.6.15+maria~ubu2204
-- PHP Version: 8.1.2-1ubuntu2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chordian_net_deepsid`
--

-- --------------------------------------------------------

--
-- Table structure for table `players_lookup`
--

CREATE TABLE `players_lookup` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `player` varchar(64) NOT NULL DEFAULT '',
  `playerid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `players_lookup`
--

INSERT INTO `players_lookup` (`id`, `player`, `playerid`) VALUES
(1, 'GoatTracker v2.x', 1),
(2, 'JCH NewPlayer v6', 2),
(3, 'JCH NewPlayer v5', 2),
(4, 'JCH NewPlayer v7', 2),
(5, 'JCH NewPlayer v8', 2),
(6, 'JCH NewPlayer v9', 2),
(7, 'JCH NewPlayer v10', 2),
(8, 'JCH NewPlayer v11', 2),
(9, 'JCH NewPlayer v12', 2),
(10, 'JCH NewPlayer v13', 2),
(11, 'JCH NewPlayer v14', 2),
(12, 'JCH NewPlayer v15', 2),
(13, 'JCH NewPlayer v17', 2),
(14, 'JCH NewPlayer v18', 3),
(15, 'JCH NewPlayer v19', 3),
(16, 'JCH NewPlayer v20', 3),
(17, 'Laxity NewPlayer v21', 3),
(18, 'CheeseCutter 2.x', 4),
(19, 'Hermit/SidWizard v1.x', 5),
(20, 'Geir Tjelta/SIDDuzz\'It', 6),
(21, 'Blackbird/LFT', 7),
(22, 'Virtuoso', 8),
(23, 'DefMon', 9),
(24, 'NinjaTracker v2.x', 10),
(25, 'Polyanna', 11),
(26, 'DMC v5.x', 12),
(27, 'SidTracker64', 13),
(28, 'DefleMask v12', 14),
(29, 'FutureComposer v1.0', 15),
(30, 'SoundMonitor/MusicMaster 1', 16),
(31, 'SoundMonitor', 16),
(32, 'Music Assembler', 17),
(33, 'DMC v4.x', 18),
(34, 'GoatTracker v1.x', 19),
(35, 'HardTrack Composer', 20),
(36, 'Master Composer', 21),
(37, 'Electro Sound', 22),
(38, 'FutureComposer v4 Packed', 23),
(39, 'CyberTracker', 24),
(40, 'CyberTracker exe', 24),
(41, 'Compute\'s SidPlayer', 25),
(42, 'Compute\'s Stereo SidPlayer', 25),
(43, 'SoedeSoft/Soundmaster v1.0', 26),
(44, 'DUSAT/RockMon2', 28),
(45, 'DUSAT/RockMon3', 29),
(46, 'DUSAT/RockMon4', 30),
(47, 'DUSAT/RockMon5.1', 31),
(48, 'John Player v1.4', 32),
(49, 'John Player v1.6', 33),
(50, 'John Player v2.0b', 34),
(51, 'OdinTracker', 35),
(52, 'TFX', 36),
(53, 'MoN/FutureComposer', 15),
(54, 'GMC/Superiors', 37),
(55, 'Digitalizer v2.x', 38),
(56, 'MusicShop', 39),
(57, 'SynC', 40),
(58, 'Asterion v1.x', 41),
(59, 'Chubrocker v3.x', 42),
(60, 'Digi-Organizer', 43),
(61, 'Ubik\'s Musik', 44),
(62, 'SidFactory/Laxity', 45),
(63, 'X-SID', 46),
(64, 'Reflextracker', 47),
(65, 'RoMuzak v6.x', 48),
(66, 'AMP', 49),
(67, 'Cyberlogic SoundStudio', 50),
(68, 'EMS/Odie', 51),
(69, 'FutureComposer v3.x', 52),
(70, 'SidWinder', 53),
(71, 'System6581', 54),
(72, 'Audial Revolution', 55),
(73, 'Digitalizer v3.0', 56),
(74, 'Sosperec', 57),
(75, 'Yip Megasound', 58),
(76, 'SoundMonitor/BeatBox/KarlXII', 59),
(77, 'Groovy Bits', 60),
(78, 'Ian Crabtree/Ariston', 61),
(79, 'PollyTracker', 62),
(80, 'SoundMaker v4', 63),
(81, 'SoundMonitor/Syndicate/BB', 64),
(82, 'Griff/Chromance', 65),
(83, 'Music Studio/Lieblich', 66),
(84, '5 Dimension', 67),
(85, 'Power Music', 68),
(86, 'Zardax\'s player/SoundKiller', 69),
(87, 'NordicBeat Editor', 70),
(88, 'Soundbooster', 71),
(89, 'GeniusComposer', 72),
(90, 'Background MusicEditor', 73),
(91, 'Comer/NMI Sample 5', 74),
(92, 'Sonic Graffiti\'s player', 75),
(93, 'SoundMonitor/DrumMaker2', 76),
(94, 'SoedeSoft/Soundmaster v3.2', 77),
(95, 'SkylineTech/Danne', 78),
(96, 'MusicComposer v3.0/Flash Inc', 79),
(97, 'CCC Editor', 80),
(98, 'Loadstar SongSmith', 81),
(99, 'Ryo kawasaki\'s player', 82),
(100, 'Kawasaki Synthesizer', 82),
(101, 'SadoTracker', 83),
(102, 'MacMusic', 84),
(103, 'PASS', 85),
(104, 'Stephan/Bytemare', 86),
(105, 'Slaygon\'s player', 87),
(106, 'Games Creator', 88),
(107, 'TrackPlayer', 89),
(108, 'Paradroid/Lameplayer', 90),
(109, 'Music Construction Set', 91),
(110, 'Artlace\'s player', 92),
(111, 'RoMuzak v7.x', 93),
(112, 'SoundMonitor/Digitronix', 94),
(113, 'Element114Studio 1.0', 95),
(114, 'Element114Studio 1.2', 95),
(116, 'Element114Studio 2.0', 96),
(117, 'Hermit/1RasterTracker', 97),
(118, 'Extra Sound', 98),
(119, 'Comer/Sample Studio', 99),
(120, 'PlayStar', 100),
(121, 'NinjaTracker v1.x', 101),
(122, 'Assassin Sample Mixer', 103),
(123, 'Sidplayer', 25),
(124, 'Kosa Protracker', 104),
(125, 'SkylineTech/Boogaloo', 78),
(126, 'Ghost/SampleMon', 105),
(127, 'ATMDS 3.x', 106),
(128, 'DigiMonitor', 107),
(129, 'DMC v6.x', 108),
(130, 'Geir Tjelta/SIDSys 1.0', 109),
(131, 'Geir Tjelta/SIDSys18.4', 110),
(132, 'Geir Tjelta/SIDSys18.6', 110),
(133, 'Mssiah', 111),
(134, 'Mjoosic Mejker', 112),
(135, 'VoiceEater', 113),
(136, 'Prosonix\'s player', 114),
(137, 'SoundWriter 2.0', 115),
(138, 'Stephen Ruddy\'s player', 116),
(139, 'Padua\'s Music Mixer', 117),
(140, 'MegaVisionMusic64', 118),
(141, 'Torpex', 119),
(142, 'JITT 1.x', 120),
(143, 'Music Processor', 121),
(144, 'SidFactory II', 122),
(145, 'Song Writer', 123),
(146, 'Jason Page\'s player/Jay', 124),
(147, 'Synth Executor', 125),
(148, 'Walt/Bonzai', 126),
(149, 'US Gold/Novaload', 128),
(150, 'Ben Daglish\'s player/WEMUSIC', 127),
(153, 'SidFactory II/Laxity', 122),
(154, 'JITT64 1.x', 120),
(155, 'DefleMask v12.1', 14),
(156, 'Ariston', 61),
(157, 'FlexSID', 129);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players_lookup`
--
ALTER TABLE `players_lookup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `playerid` (`playerid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players_lookup`
--
ALTER TABLE `players_lookup`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
